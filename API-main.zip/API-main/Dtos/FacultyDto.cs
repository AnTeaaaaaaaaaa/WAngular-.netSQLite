﻿namespace API.Dtos
{
    public class FacultyDto
    {
        public int ID { get; set; }
        public string FacultyName { get; set; }
    }
}
